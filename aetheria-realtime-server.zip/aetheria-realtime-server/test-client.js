'use strict';
/** 動作確認用クライアント: 2人がログインして歩き、互いに見えるか + チャットを検証する
 *  使い方: サーバー起動後に `node test-client.js` */
const WebSocket = require('ws');
const URL = process.env.SERVER_URL || 'ws://localhost:2567';

function makeClient(name, cls) {
  return new Promise((resolve) => {
    const ws = new WebSocket(URL);
    const c = { ws, name, snapshots: 0, chats: [], lastPlayers: [] };
    ws.on('open', () => { ws.send(JSON.stringify({ type: 'join', name, cls })); resolve(c); });
    ws.on('message', (raw) => {
      const m = JSON.parse(raw.toString());
      if (m.type === 'snapshot') { c.snapshots++; c.lastPlayers = m.players; c.you = m.you; }
      if (m.type === 'chat') c.chats.push(m);
    });
  });
}

(async () => {
  const a = await makeClient('Alice', 'warrior');
  const b = await makeClient('Bob', 'mage');
  // Alice が前に歩く入力を送り続ける
  const iv = setInterval(() => a.ws.send(JSON.stringify({ type: 'input', dx: 0, dz: -1, yaw: 0, sprint: false })), 50);
  a.ws.send(JSON.stringify({ type: 'chat', text: 'こんにちは！' }));
  await new Promise(r => setTimeout(r, 1200));
  clearInterval(iv);

  const bobSeesAlice = b.lastPlayers.some(p => p.name === 'Alice');
  const aliceMoved = a.you && a.you.z < 10;
  const bobGotChat = b.chats.some(c => c.text === 'こんにちは！');
  console.log('Alice moved on server:', aliceMoved, a.you);
  console.log('Bob sees Alice nearby:', bobSeesAlice);
  console.log('Bob received chat:', bobGotChat);
  console.log(bobSeesAlice && aliceMoved && bobGotChat ? 'TEST PASSED' : 'TEST FAILED');
  a.ws.close(); b.ws.close();
  process.exit(bobSeesAlice && aliceMoved && bobGotChat ? 0 : 1);
})().catch(e => { console.error(e); process.exit(1); });
