# AETHERIA ONLINE — リアルタイム同期サーバー (Phase 1)

プレイヤー同士のリアルタイム同期のための、ゲームサーバーの土台です。
今の AETHERIA ONLINE 本番サイト (Muse のサイト基盤) は「開く・保存する」タイプの
仕組みで常時接続ができないため、同期はこの別サーバーが担当します。
サイトは入り口と画面、今後このサーバーに WebSocket で接続します。

## 全体像

```
[ブラウザ: AETHERIAのゲーム画面]
   │  入力だけ送る (前に進む / 攻撃 / チャット)   ← WebSocket (wss://)
   ▼
[このサーバー: 常駐プロセス]  ← Render / Fly.io / VPS などに置く
   ・位置・速度上限・当たり判定の「正解」を持つ (authoritative)
   ・20回/秒 tick でゲームを進める
   ・近くにいるプレイヤー同士だけ姿を配信する (AOI 半径120)
   ▼
[ブラウザ: 相手の画面]  スナップショットの間を補間して滑らかに表示
```

## 入っているもの

| ファイル | 役割 |
|---|---|
| `server.js` | 同期サーバー本体。移動・チャット・入退室・AOI配信・速度チート防止 |
| `client/aetheria-net.js` | ブラウザ側の接続モジュール。接続・入力送信・他プレイヤーの補間表示 |
| `test-client.js` | 動作確認用。2人がログイン→歩く→互いに見える+チャット受信を自動検証 |
| `Dockerfile` | そのままクラウドに載せるための設定 |

## ローカルで動かす

```bash
npm install
npm start          # http://localhost:2567/health で生存確認
node test-client.js  # 別ターミナルで実行 → TEST PASSED が出れば同期成功
```

## 本番に置く (例: Render)

1. このフォルダを GitHub に上げる
2. Render で New → Web Service → このリポジトリを選ぶ (Dockerfile を自動検出)
3. 起動後、`https://<あなたのサービス>.onrender.com/health` が開ければOK
4. ゲーム側の接続先を `wss://<あなたのサービス>.onrender.com` にする

Fly.io なら `fly launch` → `fly deploy`、VPS なら Docker でそのまま動きます。
無料枠はスリープするサービスもあるので、本番運用では常時起動プランを選んでください。

## ゲーム側への組み込み (要点)

```js
import { AetheriaNet } from './aetheria-net.js';
const net = new AetheriaNet('wss://<サーバーのURL>');
await net.connect();
net.join(キャラ名, クラス);
// 毎フレーム: 入力を送る (位置は送らない。サーバーが決める)
net.sendInput(dx, dz, camYaw, camPitch, sprint);
// 描画ループ: 他プレイヤーを補間済み位置で表示
for (const [id, pos] of net.remotePlayers()) { /* 3Dモデルを pos へ */ }
net.onChat = (from, text) => { /* チャット欄に追加 */ };
```

今の NPC 冒険者は、最初はそのまま残して「実プレイヤーが来たら差し替わる」
形にするのが安全です。

## ロードマップ

- **Phase 1 (これ)**: 移動 + チャット + 入退室の同期
- **Phase 2**: 敵AI・戦闘・ドロップ判定をサーバー側へ移す (ここが本当の意味での完成)
- **Phase 3**: アカウント認証とキャラ保存をサーバー側DB (PostgreSQL等) に統合、
  エリア分割で1ワールドの人数を増やす、Redis で複数サーバー間の受け渡し

## 注意

- これは土台です。一般公開して課金までやる場合は、認証・レート制限・
  ログ監視・運営ポリシー (利用規約等) が別途必要です。
- サーバーの URL は公開情報ですが、DB の認証情報などは `.env` に置き、
  コードやチャットに書かないでください。
