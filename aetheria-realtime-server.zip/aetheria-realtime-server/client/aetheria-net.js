/**
 * AETHERIA ONLINE — ブラウザ側ネット接続モジュール (Phase 1)
 * 既存ゲームへの組み込み例:
 *
 *   import { AetheriaNet } from './aetheria-net.js';
 *   const net = new AetheriaNet('wss://your-server.example.com');
 *   net.join(playerName, 'mage');
 *   // 毎フレーム: キー入力をカメラ向き基準の dx/dz にして送る
 *   net.sendInput(dx, dz, camYaw, camPitch, sprint);
 *   // 描画: 他プレイヤーは補間済みの位置を取る
 *   for (const [id, pos] of net.remotePlayers()) { moveModel(id, pos.x, pos.z, pos.yaw); }
 *   net.onChat = (from, text) => addChatLine(from, text);
 */
export class AetheriaNet {
  constructor(url) {
    this.url = url;
    this.ws = null;
    this.myId = null;
    this.remotes = new Map(); // id -> { prev, curr, currAt, data }
    this.onChat = null;
    this.onLeave = null;
  }

  connect() {
    this.ws = new WebSocket(this.url);
    this.ws.onmessage = (ev) => {
      const m = JSON.parse(ev.data);
      if (m.type === 'welcome') this.myId = m.id;
      if (m.type === 'snapshot') this.#onSnapshot(m);
      if (m.type === 'chat' && this.onChat) this.onChat(m.system ? 'システム' : m.from, m.text);
      if (m.type === 'leave') {
        this.remotes.delete(m.id);
        if (this.onLeave) this.onLeave(m.id);
      }
    };
    return new Promise((res, rej) => {
      this.ws.onopen = res;
      this.ws.onerror = rej;
    });
  }

  join(name, cls) { this.#send({ type: 'join', name, cls }); }
  sendInput(dx, dz, yaw, pitch, sprint) { this.#send({ type: 'input', dx, dz, yaw, pitch, sprint }); }
  chat(text) { this.#send({ type: 'chat', text }); }
  attack(targetId) { this.#send({ type: 'attack', target: targetId }); }

  #send(obj) { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(obj)); }

  #onSnapshot(m) {
    const now = performance.now();
    const seen = new Set();
    for (const p of m.players) {
      seen.add(p.id);
      const r = this.remotes.get(p.id);
      if (!r) {
        this.remotes.set(p.id, { prev: p, curr: p, currAt: now, data: p });
      } else {
        r.prev = r.curr; r.curr = p; r.currAt = now; r.data = p;
      }
    }
    for (const id of [...this.remotes.keys()]) if (!seen.has(id)) this.remotes.delete(id);
    this.me = m.you;
  }

  /** 補間済みの他プレイヤー位置を返す (スナップショット間を滑らかに繋ぐ) */
  remotePlayers() {
    const now = performance.now();
    const out = new Map();
    for (const [id, r] of this.remotes) {
      const t = Math.min(1, Math.max(0, (now - r.currAt) / 50)); // 50ms = サーバーtick
      out.set(id, {
        ...r.data,
        x: r.prev.x + (r.curr.x - r.prev.x) * t,
        z: r.prev.z + (r.curr.z - r.prev.z) * t,
        yaw: r.curr.yaw,
      });
    }
    return out;
  }
}
